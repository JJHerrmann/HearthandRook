---
title: Welcome to Hearth and Raven
hero: true
description: A cottage in the digital woods, where lore meets ritual.
---

<div class="hero-glade">
  <h1 class="hero-title">Welcome to the Hearth</h1>
  <p class="hero-subtitle">A cottage in the digital woods, where lore meets ritual.</p>
  <a href="/rituals" class="hero-button">Enter the Ritual Library</a>
</div>