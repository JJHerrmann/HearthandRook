---
title: Hearth & Rook
description: A cottage in the digital woods, where lore meets ritual.
layout: HeroLayout
---
