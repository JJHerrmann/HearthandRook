yadda yadda yadda profile about Hermes and stuff

## Related Ceremonial Ingredients
- [[Lemon Zest]]
- [[Mint]]
- [[Sage]]
- [[Rosemary]]
- [[Lavender]]

### Related Pantheon
-[[Olymponymaicon|Olympians]]
### Related Deities
- [[Thoth]]
- [[Odin]]
- [[Mercury]]
