---
name: Zeus
pantheon: Hellenic
division: Olympian
epithets: [Thunderer, King of the Gods, Cloud-Gatherer]
symbols: [lightning bolt, eagle, oak tree]
domains: [sky, thunder, kingship, law]
primary_texts: [Theogony, Iliad, Homeric Hymns]
---
## Related Ceremonial Ingredients
- [[Lemon Zest]]
- [[Mint]]
- [[Sage]]
- [[Rosemary]]
- [[Lavender]]

### Related Pantheon
-[[Olymponymaicon|Olympians]]
### Related Deities
- [[Thoth]]
- [[Odin]]
- [[Mercury]]
