---
name: Nyx
pantheon: Hellenic
division: Primordial
epithets: [Night Incarnate, Shadow-Mother]
symbols: [veil, stars, owl]
domains: [night, mystery, prophecy]
primary_texts: [Theogony, Orphic Hymns]
---
