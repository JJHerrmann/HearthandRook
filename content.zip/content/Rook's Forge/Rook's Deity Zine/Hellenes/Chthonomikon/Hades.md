---
name: Hades
pantheon: Hellenic
division: Chthonic
epithets: [Lord of the Dead, The Unseen One, Rich One]
symbols: [helm of darkness, bident, cerberus]
domains: [underworld, wealth, death]
primary_texts: [Theogony, Homeric Hymns, Apollodorus]
---
