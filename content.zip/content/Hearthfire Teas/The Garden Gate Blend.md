#greentea #focus 
^greentea

![[Pasted image 20250516210658.png]]

Some people really like or really dislike green tea. I'm decidedly in the first camp and have been a superfan of green tea for as long as I can remember. With this cup, I chose it as my base, using it's anti-oxidant and light citrus flavor profile to help promote a sense of focus and awareness.
# A Refreshing Sense of Focus in Bone China

# Base
A [[Sencha]] or [[Gunpowder]] Green Tea serves as a delightful based for this blend, having great anti-oxident properties to pick up both body and spirit.

## Additions
*To enhance your cup*
- **Dried [[Strawberry]] or [[Raspberry Leaf]]**
- **[[Peppermint]]**
- **[[Lemon Verbena]]** or **[[Lemon Zest]]**
## Magical Properties

It opens the mind, invites abundance, and supports [[focus]] for [[spell-craft]] or [[studying]].